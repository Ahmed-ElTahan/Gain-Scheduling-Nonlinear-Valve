clc; close all; clear all;
sim('NL_Actuator');
time = step5(:, 1);

%% Step 5
h = figure;
hold all
plot(time, step5(:, 2), 'LineWidth', 2);
plot(time, step5(:, 3), 'LineWidth', 2);
plot(time, 5*ones(length(time)), ':','LineWidth', 2, 'color', 'black');
grid on
xlabel('Time (seconds) ')
ylabel('Time Response')
title('Time Response of Step Input (5) Before and After Gain Scheduling with 2 Segments')
legend('Response Before Scheduling', 'Response After Scheduling')
print(h,'-depsc','Step5')

%% Step 3
h = figure;
hold all
plot(time, step3(:, 2), 'LineWidth', 2);
plot(time, step3(:, 3), 'LineWidth', 2);
plot(time, 3*ones(length(time)), ':','LineWidth', 2, 'color', 'black');
grid on
xlabel('Time (seconds)')
ylabel('Time Response')
title('Time Response of Step Input (3) Before and After Gain Scheduling with 2 Segments')
legend('Response Before Scheduling', 'Response After Scheduling')
print(h,'-depsc','Step3')

%% Step 1
h = figure;
hold all
plot(time, step1(:, 2), 'LineWidth', 2);
plot(time, step1(:, 3), 'LineWidth', 2);
plot(time, 1*ones(length(time)), ':','LineWidth', 2, 'color', 'black');
grid on
xlabel('Time (seconds)')
ylabel('Time Response')
title('Time Response of Step Input (1) Before and After Gain Scheduling with 2 Segments')
legend('Response Before Scheduling', 'Response After Scheduling')
print(h,'-depsc', 'Step1')

%% All Before
h = figure;
hold all
plot(time, before(:, 2), 'LineWidth', 2, 'color', 'black');
plot(time, before(:, 3), 'LineWidth', 2, 'color', 'blue');
plot(time, before(:, 4), 'LineWidth', 2, 'color', 'red');
plot(time, 5*ones(length(time)), ':','LineWidth', 2, 'color', 'black');
plot(time, 3*ones(length(time)), ':','LineWidth', 2, 'color', 'blue');
plot(time, 1*ones(length(time)), ':','LineWidth', 2, 'color', 'red');
grid on
xlabel('Time (seconds) ')
ylabel('Time Response') 
title('Time Response of Step Inputs (1, 3, 5) Before Gain Scheduling with 2 Segments')
legend('Step 5', 'Step 3', 'Step 1')
print(h,'-depsc','Before')

%% All After
h = figure;
hold all
plot(time, after(:, 2), 'LineWidth', 2, 'color', 'black');
plot(time, after(:, 3), 'LineWidth', 2, 'color', 'blue');
plot(time, after(:, 4), 'LineWidth', 2, 'color', 'red');
plot(time, 5*ones(length(time)), ':','LineWidth', 2, 'color', 'black');
plot(time, 3*ones(length(time)), ':','LineWidth', 2, 'color', 'blue');
plot(time, 1*ones(length(time)), ':','LineWidth', 2, 'color', 'red');
grid on
xlabel('Time (seconds) ')
ylabel('Time Response')
title('Time Response of Step Inputs (1, 3, 5) After Gain Scheduling with 2 Segments')
legend('Step 5', 'Step 3', 'Step 1')
print(h,'-depsc','After')

%% All on All
h = figure;
hold all
plot(time, before(:, 2), 'LineWidth', 2, 'color', 'black');
plot(time, after(:, 2), '--','LineWidth', 2, 'color', 'black');
plot(time, before(:, 3), 'LineWidth', 2, 'color', 'blue');
plot(time, after(:, 3), '--','LineWidth', 2, 'color', 'blue');
plot(time, before(:, 4), 'LineWidth', 2, 'color', 'red');
plot(time, after(:, 4), '--','LineWidth', 2, 'color', 'red');
plot(time, 5*ones(length(time)  ), ':','LineWidth', 2, 'color', 'black');
plot(time, 3*ones(length(time)), ':','LineWidth', 2, 'color', 'blue');
plot(time, 1*ones(length(time)), ':','LineWidth', 2, 'color', 'red');
grid on
xlabel('Time (seconds) ')
ylabel('Time Response')
title('All Time Responses of Step Input (1, 3, 5) Before and After Gain Scheduling')
legend('Response Before Scheduling Step 5', 'Response After Scheduling Step 5', 'Response Before Scheduling Step 3', 'Response After Scheduling Step 3', 'Response Before Scheduling Step 1', 'Response After Scheduling Step 1')
print(h,'-depsc','AllonAll')
